import 'package:flutter/material.dart';
import 'package:flutter_list/userdata.dart';
import 'package:flutter_list/useritem.dart';
import 'package:flutter_list/userlist.dart';

void main() {
  // UserData userUmam = UserData(umam, 22, miftahulumam862@gmail.com);
  runApp(UserList());
}
